<?php

use Faker\Factory as Faker;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/a', function () {
    // dd(');
    $faker = Faker::create();

    return $faker->image($dir = 'http://localhost/tmp', $width = 640, $height = 480);
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
